import {loadFont as loadSerif} from '@remotion/google-fonts/CormorantGaramond';
import {loadFont as loadSans} from '@remotion/google-fonts/Inter';
import {loadFont as loadAr} from '@remotion/google-fonts/Amiri';
export const serif = loadSerif('normal', {weights: ['600', '700'], subsets: ['latin', 'latin-ext']}).fontFamily;
export const sans = loadSans('normal', {weights: ['400', '600'], subsets: ['latin']}).fontFamily;
export const arabic = loadAr('normal', {weights: ['400', '700'], subsets: ['arabic']}).fontFamily;
export const C = {ink: '#120d07', parch: '#d9c49a', parchDark: '#b79b66', sea: '#16303a', seaDeep: '#0b1a21', gold: '#e8c872', emerald: '#2f9e7a', rose: '#b4533f', text: '#f6ecd5'};
