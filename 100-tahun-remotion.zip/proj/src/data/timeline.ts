import {FPS} from './geo';
// DURASI AUDIO TERUKUR (ffprobe): 228.284063 s  ->  ceil(228.284063*30) = 6849 frame
export const AUDIO_SECONDS = 228.284063;
export const TOTAL_FRAMES = Math.ceil(AUDIO_SECONDS * FPS);
export const sec = (s: number) => Math.round(s * FPS);

export type Visual = 'map' | 'manuscript' | 'army';
export type Whoosh = 'soft' | 'deep' | 'sweep' | 'none';
export interface Scene {
  id: string;
  start: number; // detik (dari jeda suara pada MP3; EDITABLE)
  end: number;
  cam: {lon: number; lat: number; z: number};
  visual?: Visual;
  kicker?: string;
  title?: string;
  sub?: string;
  year?: string;
  people?: string[];
  markers?: {city: string; at: number}[]; // at = detik relatif awal scene
  arrows?: {from: string; to: string; at: number; dur: number}[];
  reach?: {city: string; r: number; tone?: 'gold' | 'emerald' | 'rose'}[];
  impact?: 'deep' | 'soft';
  whoosh?: Whoosh;
  swell?: boolean;
  ar?: string; // teks Arab (visual manuscript)
}
// Batas diambil dari deteksi jeda (ffmpeg silencedetect) + penyelarasan proporsional per karakter.
// Tidak ada ASR di lingkungan pembuatan -> verifikasi manual disarankan (lihat README).
export const SCENES: Scene[] = [
  {id: 'opening', start: 0, end: 8.5, cam: {lon: 40, lat: 24, z: 2.4}, kicker: 'DOKUMENTER SEJARAH', title: '100 TAHUN YANG MENGUBAH DUNIA', sub: 'Perjalanan Perluasan Wilayah Islam, 632–732 M', impact: 'deep', swell: true, markers: [{city: 'madinah', at: 5}], reach: []},
  {id: 'intro', start: 8.5, end: 22.84, cam: {lon: 36, lat: 33, z: 0.95}, kicker: 'SATU ABAD', title: 'Dari perbatasan India hingga Semenanjung Iberia', year: '632 – 732 M', whoosh: 'deep', markers: [{city: 'madinah', at: 0.5}, {city: 'debal', at: 6}, {city: 'gibraltar', at: 9}], reach: [{city: 'madinah', r: 5, tone: 'gold'}]},
  {id: 'tanya', start: 22.84, end: 29.4, cam: {lon: 36, lat: 33, z: 1.15}, title: 'Bagaimana semua ini terjadi?', sub: 'Siapa para pemimpin di baliknya?', whoosh: 'soft'},
  {id: 'wafat', start: 29.4, end: 35.0, cam: {lon: 39.6, lat: 24.4, z: 3.2}, visual: 'manuscript', kicker: 'TAHUN 632 M', title: 'Kepemimpinan berlanjut', sub: 'Madinah', year: '632', ar: 'المدينة المنورة', impact: 'soft', whoosh: 'deep', markers: [{city: 'madinah', at: 1.2}]},
  {id: 'abubakar', start: 35.0, end: 50.65, cam: {lon: 43, lat: 25, z: 2.3}, kicker: 'KHALIFAH PERTAMA', title: 'Abu Bakar ash-Shiddiq', sub: 'Perang Riddah — menyatukan kembali Jazirah Arab', year: '632–634', people: ['Abu Bakar ash-Shiddiq'], whoosh: 'soft', markers: [{city: 'madinah', at: 0.5}, {city: 'makkah', at: 6}], reach: [{city: 'madinah', r: 9, tone: 'gold'}]},
  {id: 'transisi-umar', start: 50.65, end: 56.4, cam: {lon: 40, lat: 28, z: 2.0}, kicker: 'KHALIFAH KEDUA', title: 'Umar bin Khattab', year: '634', people: ['Umar bin Khattab'], impact: 'soft', whoosh: 'sweep'},
  {id: 'umar', start: 56.4, end: 79.2, cam: {lon: 38, lat: 31, z: 1.8}, visual: 'army', kicker: 'PERLUASAN PESAT', title: 'Yarmuk, 636 M', sub: 'Syam · Palestina · Mesir · Persia', year: '636', whoosh: 'deep', swell: true, markers: [{city: 'yarmuk', at: 3}, {city: 'damaskus', at: 8}, {city: 'yerusalem', at: 10.5}, {city: 'fustat', at: 14}, {city: 'ctesiphon', at: 18}], arrows: [{from: 'madinah', to: 'damaskus', at: 6, dur: 3}, {from: 'damaskus', to: 'fustat', at: 12, dur: 3}, {from: 'madinah', to: 'ctesiphon', at: 16, dur: 3}], reach: [{city: 'damaskus', r: 5, tone: 'gold'}, {city: 'fustat', r: 5, tone: 'gold'}, {city: 'ctesiphon', r: 6, tone: 'gold'}]},
  {id: 'utsman', start: 79.2, end: 88.7, cam: {lon: 25, lat: 33, z: 1.35}, kicker: 'KHALIFAH KETIGA', title: 'Utsman bin Affan', sub: 'Persia · Afrika Utara · kekuatan maritim', year: '644–656', people: ['Utsman bin Affan'], impact: 'soft', whoosh: 'soft', markers: [{city: 'isfahan', at: 2.5}, {city: 'kairouan', at: 5}], arrows: [{from: 'fustat', to: 'kairouan', at: 4, dur: 3.5}], reach: [{city: 'isfahan', r: 6, tone: 'gold'}, {city: 'kairouan', r: 5, tone: 'gold'}]},
  {id: 'konflik', start: 88.7, end: 91.65, cam: {lon: 38, lat: 31, z: 1.7}, title: 'Namun sejarah tidak selalu tanpa konflik', swell: true, whoosh: 'sweep'},
  {id: 'ali', start: 91.65, end: 112.4, cam: {lon: 37.5, lat: 32, z: 2.6}, kicker: 'KHALIFAH KEEMPAT · 656–661', title: 'Ali bin Abi Thalib', sub: 'Perpecahan politik & perang saudara', year: '661', people: ['Ali bin Abi Thalib', 'Muawiyah bin Abi Sufyan'], impact: 'deep', whoosh: 'deep', markers: [{city: 'damaskus', at: 11}], reach: [{city: 'damaskus', r: 7, tone: 'emerald'}]},
  {id: 'abdulmalik', start: 112.4, end: 123.2, cam: {lon: 36.3, lat: 33.5, z: 3.0}, kicker: 'DINASTI UMAYYAH', title: 'Abdul Malik bin Marwan', sub: 'Administrasi diperkuat · bahasa Arab dominan dalam birokrasi', people: ['Abdul Malik bin Marwan'], whoosh: 'soft', markers: [{city: 'damaskus', at: 0.5}]},
  {id: 'walid', start: 123.2, end: 126.0, cam: {lon: 36.3, lat: 33.5, z: 2.0}, kicker: 'PUNCAK EKSPANSI', title: 'Al-Walid bin Abdul Malik', people: ['Al-Walid bin Abdul Malik'], impact: 'soft', whoosh: 'sweep'},
  {id: 'iberia', start: 126.0, end: 143.6, cam: {lon: 2, lat: 38.5, z: 2.5}, kicker: 'SEMENANJUNG IBERIA', title: 'Tahun 711 M', sub: 'Tariq bin Ziyad · Musa bin Nushair', year: '711', people: ['Tariq bin Ziyad', 'Musa bin Nushair'], impact: 'deep', whoosh: 'deep', markers: [{city: 'kairouan', at: 3}, {city: 'gibraltar', at: 6}, {city: 'cordoba', at: 9}, {city: 'toledo', at: 11}], arrows: [{from: 'kairouan', to: 'gibraltar', at: 5, dur: 3}], reach: [{city: 'cordoba', r: 5, tone: 'gold'}]},
  {id: 'timur', start: 143.6, end: 157.74, cam: {lon: 66, lat: 32, z: 1.9}, kicker: 'DI SEBELAH TIMUR', title: 'Sindh & Asia Tengah', sub: 'Muhammad bin Qasim · Qutayba bin Muslim', people: ['Muhammad bin Qasim', 'Qutayba bin Muslim'], whoosh: 'deep', markers: [{city: 'debal', at: 2}, {city: 'multan', at: 4.5}, {city: 'merv', at: 8}, {city: 'samarkand', at: 10}], arrows: [{from: 'ctesiphon', to: 'debal', at: 2, dur: 3}, {from: 'isfahan', to: 'samarkand', at: 8, dur: 3}], reach: [{city: 'debal', r: 5, tone: 'gold'}, {city: 'samarkand', r: 6, tone: 'gold'}]},
  {id: 'tours', start: 157.74, end: 171.53, cam: {lon: 2, lat: 44, z: 3.0}, visual: 'army', kicker: 'EROPA BARAT', title: 'Tours–Poitiers, 732 M', sub: 'Pasukan Umayyah berhadapan dengan pasukan Frank', year: '732', impact: 'deep', swell: true, whoosh: 'deep', markers: [{city: 'tours', at: 3}], reach: [{city: 'tours', r: 3, tone: 'rose'}]},
  {id: 'jeda', start: 171.53, end: 174.5, cam: {lon: 36, lat: 33, z: 1.0}, title: 'Ada satu hal yang harus kita pahami', whoosh: 'sweep', swell: true},
  {id: 'islamisasi', start: 174.5, end: 191.3, cam: {lon: 38, lat: 33, z: 1.2}, kicker: 'BEDAKAN', title: 'Pemerintahan ≠ Keyakinan', sub: 'Islamisasi berlangsung bertahap, selama beberapa generasi', whoosh: 'soft', markers: [{city: 'fustat', at: 4}, {city: 'damaskus', at: 6}, {city: 'samarkand', at: 8}]},
  {id: 'penutup', start: 191.3, end: 207.6, cam: {lon: 36, lat: 33, z: 0.95}, kicker: 'WARISAN', title: 'Kisah terbentuknya pemerintahan baru dan pertemuan peradaban', year: '632 – 732', impact: 'soft', whoosh: 'deep', reach: [{city: 'isfahan', r: 8, tone: 'gold'}, {city: 'cordoba', r: 6, tone: 'gold'}, {city: 'debal', r: 6, tone: 'gold'}]},
  {id: 'tanya2', start: 207.6, end: 217.1, cam: {lon: 36, lat: 33, z: 1.0}, title: 'Faktor apa yang paling berpengaruh?', sub: 'Kepemimpinan · Perdagangan · Dakwah · Pertemuan antarperadaban', whoosh: 'soft'},
  {id: 'cta', start: 217.1, end: 228.284063, cam: {lon: 36, lat: 33, z: 0.95}, title: 'Tulis pendapatmu di kolom komentar', sub: 'Usulkan topik kajian untuk video berikutnya', whoosh: 'soft'},
];
