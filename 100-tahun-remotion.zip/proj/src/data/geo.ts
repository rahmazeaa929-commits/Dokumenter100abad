// Peta SKEMATIS-ILUSTRATIF. Garis pantai disederhanakan dengan tangan; BUKAN data geografis presisi.
export const FPS = 30;
export const W = 1080;
export const H = 1920;
export const LON0 = -12, LAT1 = 56, PX_LON = 20, PX_LAT = 22;
export const MAP_W = 97 * PX_LON; // lon -12..85
export const MAP_H = 51 * PX_LAT; // lat 56..5
export const proj = (lon: number, lat: number): [number, number] => [(lon - LON0) * PX_LON, (LAT1 - lat) * PX_LAT];
export type LL = [number, number];
export const CITIES: Record<string, {n: string; p: LL}> = {
  madinah: {n: 'Madinah', p: [39.61, 24.47]},
  makkah: {n: 'Makkah', p: [39.83, 21.42]},
  damaskus: {n: 'Damaskus', p: [36.29, 33.51]},
  yarmuk: {n: 'Yarmuk', p: [35.97, 32.74]},
  yerusalem: {n: 'Palestina', p: [35.2, 31.8]},
  fustat: {n: 'Mesir', p: [31.24, 30.04]},
  ctesiphon: {n: 'Persia (Sasaniyah)', p: [44.58, 33.09]},
  isfahan: {n: 'Persia', p: [51.67, 32.65]},
  kairouan: {n: 'Afrika Utara', p: [10.1, 35.68]},
  gibraltar: {n: 'Gibraltar', p: [-5.35, 36.14]},
  cordoba: {n: 'Andalusia', p: [-4.78, 37.88]},
  toledo: {n: 'Toledo', p: [-4.02, 39.86]},
  tours: {n: 'Tours–Poitiers', p: [0.5, 47.0]},
  debal: {n: 'Sindh', p: [67.0, 24.85]},
  multan: {n: 'Multan', p: [71.47, 30.2]},
  samarkand: {n: 'Asia Tengah', p: [66.96, 39.65]},
  merv: {n: 'Merv', p: [62.19, 37.66]},
};
export const poly = (pts: LL[]) => pts.map(([a, b]) => proj(a, b).join(',')).join(' ');
export const LAND: LL[] = [[-12, 56], [85, 56], [85, 5], [-12, 5]];
export const SEAS: Record<string, LL[]> = {
  atlantik: [[-12, 56], [-10, 56], [-10, 43.5], [-9.2, 43.2], [-9.5, 38.7], [-8.9, 37], [-6.3, 36.5], [-5.6, 36], [-6, 34], [-9.8, 31], [-12, 26]],
  tengah: [[-5.6, 36], [-2, 36.7], [0, 38.5], [0.3, 40.5], [3.2, 42], [5, 43.3], [8, 43.8], [10, 44], [12.5, 41.5], [15.5, 38], [16, 40], [18.5, 40.2], [16, 41.8], [13, 44.5], [14, 45.5], [19, 42], [21, 40], [23, 37], [26, 36.8], [30, 36.2], [36, 36.5], [35.8, 34], [35, 31.5], [32.3, 31.2], [30, 31], [25, 31.8], [20, 32.2], [15, 32.3], [11, 33], [10.2, 34], [11, 37], [9, 37.2], [2, 36.8], [-2, 35.2], [-5.5, 35.9]],
  merah: [[32.6, 29.9], [34.5, 28], [35, 27.5], [39, 21.5], [42.7, 16.5], [43.2, 12.7], [42, 12.5], [39.5, 15.5], [37.2, 19], [35.5, 24]],
  teluk: [[48, 30.2], [50, 30.3], [51.5, 28.5], [54, 26.6], [56.5, 27.2], [56.4, 26], [54, 24.2], [51.5, 24.5], [50.7, 26], [50, 28], [48.5, 29.8]],
  hindia: [[43.2, 12.7], [52, 16], [57, 19], [59.5, 22.5], [61, 25], [66, 25.2], [67.5, 24.5], [70, 21], [72.7, 21], [73, 17], [74.5, 12], [77.5, 8], [80, 10], [80.3, 13], [82, 16.5], [85, 21], [85, 5], [51, 5], [48, 5], [51, 10.5]],
  hitam: [[28, 41.5], [33, 42], [37, 41.2], [41.5, 41.5], [41.5, 43], [38, 45], [34, 46], [31, 46.4], [29, 44.5]],
  kaspia: [[47, 45], [53, 47], [54, 42], [54, 37], [49, 37], [49, 40], [47.5, 42]],
};
export const MOUNTS: LL[] = [[46, 35], [48, 33], [50, 31], [53, 30], [34, 38], [37, 37.5], [44, 42.5], [42, 42.5], [62, 36], [68, 35], [71, 36.5], [0, 42.5], [-2, 42.8], [-4, 36.5], [3, 33], [-3, 32], [7, 34]];
