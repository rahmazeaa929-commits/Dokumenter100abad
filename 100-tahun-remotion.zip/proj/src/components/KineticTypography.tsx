import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame} from 'remotion';
import {Scene, sec} from '../data/timeline';
import {C, sans, serif} from '../theme';

const ease = Easing.bezier(0.16, 1, 0.3, 1);
const rise = (f: number, d: number, len = 24) => interpolate(f - d, [0, len], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: ease});

const Words: React.FC<{text: string; size: number; delay: number; color?: string; family?: string; weight?: number}> = ({text, size, delay, color = C.text, family = serif, weight = 700}) => {
  const f = useCurrentFrame();
  return (
    <div style={{display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: `0 ${size * 0.28}px`, fontFamily: family, fontWeight: weight, fontSize: size, lineHeight: 1.08, color, textShadow: '0 4px 28px rgba(0,0,0,.85)'}}>
      {text.split(' ').map((w, i) => { const t = rise(f, delay + i * 4); return (
        <span key={i} style={{display: 'inline-block', opacity: t, transform: `translateY(${(1 - t) * 38}px)`, filter: `blur(${(1 - t) * 8}px)`}}>{w}</span>); })}
    </div>
  );
};

/** Teks layar relatif terhadap awal scene. Area aman: 230px atas, 380px bawah. */
export const KineticTypography: React.FC<{scene: Scene}> = ({scene}) => {
  const f = useCurrentFrame(); const dur = sec(scene.end) - sec(scene.start);
  const out = interpolate(f, [dur - 18, dur], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const big = scene.id === 'opening';
  const len = (scene.title ?? '').length;
  const size = big ? 104 : len > 40 ? 62 : len > 24 ? 74 : 88;
  return (
    <AbsoluteFill style={{opacity: out}}>
      {scene.year && (
        <div style={{position: 'absolute', top: 250, width: '100%', textAlign: 'center', opacity: rise(f, 8, 30), transform: `scale(${0.92 + 0.08 * rise(f, 8, 30)})`, fontFamily: serif, fontWeight: 700, fontSize: 140, letterSpacing: 6, color: C.gold, textShadow: '0 0 40px rgba(232,200,114,.45), 0 4px 20px #000'}}>
          {scene.year}{/^\d{3,4}$/.test(scene.year) ? ' M' : ''}
        </div>)}
      <div style={{position: 'absolute', top: scene.year ? 440 : 280, width: '100%', textAlign: 'center'}} />
      <div style={{position: 'absolute', left: 70, right: 70, top: 1130, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 22}}>
        {scene.kicker && <div style={{fontFamily: sans, fontWeight: 600, fontSize: 28, letterSpacing: 8, color: C.gold, opacity: rise(f, 4), borderBottom: `2px solid rgba(232,200,114,${0.6 * rise(f, 6, 40)})`, paddingBottom: 10}}>{scene.kicker}</div>}
        {scene.title && <Words text={scene.title} size={size} delay={8} />}
        {scene.sub && <div style={{fontFamily: sans, fontSize: 34, lineHeight: 1.35, textAlign: 'center', color: 'rgba(246,236,213,.9)', opacity: rise(f, 30), transform: `translateY(${(1 - rise(f, 30)) * 20}px)`, textShadow: '0 2px 16px #000', maxWidth: 900}}>{scene.sub}</div>}
      </div>
      {scene.people && (
        <div style={{position: 'absolute', left: 60, bottom: 400, display: 'flex', flexDirection: 'column', gap: 10}}>
          {scene.people.map((p, i) => { const t = rise(f, 50 + i * 12); return (
            <div key={p} style={{opacity: t, transform: `translateX(${(1 - t) * -60}px)`, display: 'flex', alignItems: 'center', gap: 14}}>
              <div style={{width: 6, height: 44, background: C.gold, transform: `scaleY(${t})`}} />
              <div style={{fontFamily: sans, fontWeight: 600, fontSize: 32, color: C.text, background: 'rgba(10,6,2,.55)', padding: '8px 18px', borderRadius: 4}}>{p}</div>
            </div>); })}
        </div>)}
    </AbsoluteFill>
  );
};
