import React from 'react';
import {AbsoluteFill, interpolate, staticFile, useCurrentFrame} from 'remotion';
export const ColorGrading: React.FC<{total: number}> = ({total}) => {
  const f = useCurrentFrame();
  const open = interpolate(f, [0, 75], [1, 0], {extrapolateRight: 'clamp'});
  const close = interpolate(f, [total - 45, total - 1], [0, 1], {extrapolateLeft: 'clamp'});
  const sweep = ((f % 540) / 540) * 2400 - 600;
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 45%, rgba(0,0,0,0) 40%, rgba(5,3,1,0.72) 100%)'}} />
      <AbsoluteFill style={{background: 'linear-gradient(180deg, rgba(255,170,60,0.06), rgba(10,30,50,0.14))', mixBlendMode: 'soft-light'}} />
      <AbsoluteFill style={{background: `linear-gradient(105deg, transparent ${sweep - 250}px, rgba(255,230,170,0.05) ${sweep}px, transparent ${sweep + 250}px)`}} />
      <AbsoluteFill style={{backgroundImage: `url(${staticFile('grain.png')})`, backgroundPosition: `${(f * 37) % 256}px ${(f * 91) % 256}px`, opacity: 0.11, mixBlendMode: 'overlay'}} />
      <AbsoluteFill style={{background: '#000', opacity: Math.max(open, close)}} />
    </AbsoluteFill>
  );
};
