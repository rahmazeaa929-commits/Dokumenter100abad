import {Easing, interpolate} from 'remotion';
import {SCENES, sec} from '../data/timeline';
import {CITIES, proj, W, H, PX_LON} from '../data/geo';
const FIT = W / (97 * PX_LON);
export interface Cam {x: number; y: number; s: number}
const toCam = (i: number): Cam => {
  const c = SCENES[i].cam; const [x, y] = proj(c.lon, c.lat); return {x, y, s: FIT * c.z * 1.6};
};
export const sceneIndexAt = (f: number) => {
  const i = SCENES.findIndex((s) => f < sec(s.end));
  return i < 0 ? SCENES.length - 1 : i;
};
/** Kamera virtual: transisi eased dari scene sebelumnya + drift lambat (dolly) di dalam scene. */
export const cameraAt = (f: number): Cam => {
  const i = sceneIndexAt(f); const sc = SCENES[i]; const start = sec(sc.start); const dur = sec(sc.end) - start;
  const cur = toCam(i); const prev = i > 0 ? toCam(i - 1) : cur;
  const T = Math.min(60, dur);
  const k = interpolate(f - start, [0, T], [0, 1], {extrapolateRight: 'clamp', easing: Easing.bezier(0.65, 0, 0.25, 1)});
  const drift = interpolate(f - start, [0, dur], [0, 1]);
  const lg = Math.exp(Math.log(prev.s) * (1 - k) + Math.log(cur.s) * k);
  return {x: prev.x + (cur.x - prev.x) * k + drift * 18, y: prev.y + (cur.y - prev.y) * k - drift * 10, s: lg * (1 + drift * 0.06)};
};
export const cityXY = (k: string) => proj(...CITIES[k].p);
export const cameraTransform = (c: Cam) => `translate(${W / 2},${H / 2 - 120}) scale(${c.s}) translate(${-c.x},${-c.y})`;
