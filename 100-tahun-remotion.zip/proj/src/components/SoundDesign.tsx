import React from 'react';
import {Audio, Sequence, interpolate, staticFile} from 'remotion';
import {SCENES, sec, TOTAL_FRAMES, Whoosh} from '../data/timeline';

const sfx = (n: string) => staticFile(`sfx/${n}.wav`);
const WH: Record<Exclude<Whoosh, 'none'>, [string, number]> = {soft: ['whoosh_soft', 0.22], deep: ['whoosh_deep', 0.3], sweep: ['sweep_fast', 0.2]};
const Hit: React.FC<{at: number; dur: number; src: string; vol: number}> = ({at, dur, src, vol}) => (
  <Sequence from={Math.max(0, at)} durationInFrames={dur} layout="none"><Audio src={src} volume={vol} /></Sequence>
);
/** Semua cue ditempatkan dari timeline scene; level dibuat jauh di bawah narasi (ducking statis). */
export const SoundDesign: React.FC = () => {
  const cues: React.ReactNode[] = [];
  SCENES.forEach((s, i) => {
    const st = sec(s.start); const k = s.id;
    if (s.impact) cues.push(<Hit key={k + 'i'} at={st + 4} dur={sec(3.2)} src={sfx(s.impact === 'deep' ? 'impact_deep' : 'impact_soft')} vol={s.impact === 'deep' ? 0.38 : 0.28} />);
    if (s.whoosh && s.whoosh !== 'none') { const [n, v] = WH[s.whoosh]; cues.push(<Hit key={k + 'w'} at={st - 8} dur={sec(2.4)} src={sfx(n)} vol={v} />); }
    if (s.swell) cues.push(<Hit key={k + 's'} at={Math.max(0, sec(s.end) - sec(3.6))} dur={sec(4)} src={sfx('swell_reverse')} vol={0.2} />);
    if (s.year) cues.push(<Hit key={k + 'y'} at={st + 14} dur={sec(1.6)} src={sfx('chime')} vol={0.2 + (i % 3) * 0.02} />);
    s.markers?.forEach((m, j) => cues.push(<Hit key={`${k}m${j}`} at={st + sec(m.at)} dur={sec(0.35)} src={sfx('tick')} vol={0.17 + (j % 2) * 0.03} />));
    s.arrows?.forEach((a, j) => cues.push(<Hit key={`${k}a${j}`} at={st + sec(a.at)} dur={sec(0.8)} src={sfx('sweep_fast')} vol={0.12} />));
  });
  // Atmosfer: rumble + angin (loop 30 dtk, fade internal 3 dtk), volume diautomasi; turun di bagian konflik.
  const bed = (f: number) => interpolate(f, [0, 90, TOTAL_FRAMES - 150, TOTAL_FRAMES - 20], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <>
      <Audio src={sfx('rumble_bed')} loop volume={(f) => 0.1 * bed(f)} />
      <Audio src={sfx('wind_bed')} loop volume={(f) => 0.07 * bed(f)} />
      {cues}
    </>
  );
};
