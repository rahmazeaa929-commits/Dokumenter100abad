import React from 'react';
import {Audio, staticFile} from 'remotion';
/** Narasi asli 100abad.mp3: utuh, volume 1, dari frame 0. Master timeline. */
export const AudioMaster: React.FC = () => <Audio src={staticFile('100abad.mp3')} volume={1} />;
