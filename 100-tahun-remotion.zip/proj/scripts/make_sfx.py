#!/usr/bin/env python3
"""Generate procedural SFX (44.1kHz mono 16-bit WAV) into public/sfx. Deterministic (fixed seed)."""
import numpy as np, wave, os
from scipy.signal import butter, sosfilt
SR=44100; rng=np.random.default_rng(632)
out=os.path.join(os.path.dirname(__file__),'..','public','sfx'); os.makedirs(out,exist_ok=True)
def t(d): return np.arange(int(SR*d))/SR
def bp(x,lo,hi,o=2): return sosfilt(butter(o,[lo,hi],btype='band',fs=SR,output='sos'),x)
def lp(x,f,o=2): return sosfilt(butter(o,f,btype='low',fs=SR,output='sos'),x)
def env(n,a,r):
    e=np.ones(n); na=int(a*SR); nr=int(r*SR)
    e[:na]=np.linspace(0,1,na)**2; e[-nr:]=np.linspace(1,0,nr)**2; return e
def save(name,x,peak=0.5):
    x=x/(np.max(np.abs(x))+1e-9)*peak
    n=int(0.01*SR); x[:n]*=np.linspace(0,1,n); x[-n:]*=np.linspace(1,0,n)
    with wave.open(os.path.join(out,name+'.wav'),'wb') as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(SR);w.writeframes((x*32767).astype('<i2').tobytes())
def impact(d=3.2):
    x=t(d); f=55*np.exp(-x*1.6)+32
    s=np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-x*1.3)
    n=lp(rng.standard_normal(len(x)),400)*np.exp(-x*5)*0.6
    tail=lp(rng.standard_normal(len(x)),180)*np.exp(-x*1.1)*0.25
    return s+n+tail
def whoosh(d,lo,hi,peak_at=0.5):
    x=t(d); n=rng.standard_normal(len(x))
    c=lo*(hi/lo)**(np.minimum(x/(d*peak_at),1)) # rising cutoff
    y=np.zeros_like(n); blk=512
    for i in range(0,len(n),blk):
        f=min(c[i],SR*0.45); y[i:i+blk]=lp(n[i:i+blk],f,1) if False else n[i:i+blk]
    # simple time-varying band: crossfade of 3 fixed bands
    b1=bp(n,lo,lo*2.5);b2=bp(n,lo*2,hi);b3=bp(n,hi*0.6,min(hi*2,20000))
    p=np.clip(x/(d*peak_at),0,1); q=np.clip((x-d*peak_at)/(d*(1-peak_at)),0,1)
    w=(b1*(1-p)+b2*p)*(1-q)+b3*q*0.4
    sh=np.sin(np.pi*x/d)**2
    return w*sh
def swell(d=4.0):
    x=t(d); n=bp(rng.standard_normal(len(x)),150,2500)
    tone=sum(np.sin(2*np.pi*f*x*(1+0.02*x/d)) for f in (110,164.8,220))*0.15
    return (n*0.5+tone)*(x/d)**3*np.minimum(1,(d-x)/0.08)
def tick():
    x=t(0.35); return (np.sin(2*np.pi*880*x)+0.4*np.sin(2*np.pi*1320*x))*np.exp(-x*22)
def chime():
    x=t(1.6); return sum(a*np.sin(2*np.pi*f*x)*np.exp(-x*k) for f,a,k in((523.3,1,3.2),(784,.5,3.8),(1046.5,.3,5)))
def rumble(d=30):
    x=t(d); n=lp(rng.standard_normal(len(x)),90,3)
    m=1+0.3*np.sin(2*np.pi*0.11*x)+0.2*np.sin(2*np.pi*0.047*x+1)
    d_=np.sin(2*np.pi*41*x)*0.15
    return (n*m+d_)*env(len(x),3,3)
def wind(d=30):
    x=t(d); n=rng.standard_normal(len(x))
    b=bp(n,300,1800,2)*(0.6+0.4*np.sin(2*np.pi*0.09*x))+bp(n,700,3500,2)*0.25*(0.5+0.5*np.sin(2*np.pi*0.173*x+2))
    return b*env(len(x),3,3)
save('impact_deep',impact(),0.9)
save('impact_soft',impact(2.4)*0.6,0.6)
save('whoosh_soft',whoosh(1.4,300,3000),0.5)
save('whoosh_deep',whoosh(2.4,120,1800,0.45),0.7)
save('sweep_fast',whoosh(0.8,800,7000,0.55),0.5)
save('swell_reverse',swell(4.0),0.6)
save('tick',tick(),0.35)
save('chime',chime(),0.35)
save('rumble_bed',rumble(30),0.8)
save('wind_bed',wind(30),0.6)
print('ok')
